public class Shot extends GameChar{
    public Shot(){ 
        
    }
    
    public Shot(int x, int y){
        super (x,y);
    }
}
