import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
public class Player extends GameChar{
    public Player(){ 
        
    }
    
    public Player(int x, int y){
        super(x,y);
    }
}