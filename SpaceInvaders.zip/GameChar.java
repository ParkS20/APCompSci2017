public class GameChar{
    int x; 
    int y; 
    public GameChar(){ 
        
    }
    
    public GameChar(int x, int y){
        this.x=x; 
        this.y=y; 
    }
}