public class Alien extends GameChar{
    public Alien(){ 
        
    }
    
    public Alien(int x, int y){
        super (x,y);
    }
}
